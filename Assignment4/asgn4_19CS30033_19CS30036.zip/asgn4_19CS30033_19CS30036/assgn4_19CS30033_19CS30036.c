#include "stdio.h"
#include "y.tab.h"

void main(){
    yyparse() ;
}