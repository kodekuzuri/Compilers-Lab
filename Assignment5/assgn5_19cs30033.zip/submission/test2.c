int divide(int a, int b){
	return a/b;
}

int mult(int a, int b) //typecasting
{
	return a * b;
}

int main()
{
	int q=0,r=0;
	q = mult(2,3);
	r=10;

	int c;
	c = divide(r,2);
	return;
}
